#include "RssReader.h"
#include "tinyxml2.h"
#include "getName.h"

#include <boost/regex.hpp>
#include <boost/algorithm/string.hpp>

#include <stdio.h>

#include <iostream>
#include <fstream>

using std::string;
using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::ofstream;

using namespace tinyxml2;

void RssItem::writeToFile(ofstream & ofs)
{
    ofs << "<title> " << title << " </title>" << endl;
    ofs << "<link> " << link << " </link>" << endl;
    ofs << "<description> " << description << " </description>" << endl;
    ofs << "<content> " << content << " </content>" << endl;
}

//	这个方法是用来返回指定路径下文件名的
vector<string> getFiles(string cate_dir)
{
	vector<string> files;//存放文件名


	DIR *dir;
	struct dirent *ptr;
	char base[1000];

	if ((dir=opendir(cate_dir.c_str())) == NULL)
	{
		perror("Open dir error...");
		exit(1);
	}

	while ((ptr=readdir(dir)) != NULL)
	{
		if(strcmp(ptr->d_name,".")==0 || strcmp(ptr->d_name,"..")==0)    ///current dir OR parrent dir
			continue;
		else if(ptr->d_type == 8)    ///file
			//printf("d_name:%s/%s\n",basePath,ptr->d_name);
			files.push_back(ptr->d_name);
		else if(ptr->d_type == 10)    ///link file
			//printf("d_name:%s/%s\n",basePath,ptr->d_name);
			continue;
		else if(ptr->d_type == 4)    ///dir
		{
			files.push_back(ptr->d_name);
			/*
			   memset(base,'\0',sizeof(base));
			   strcpy(base,basePath);
			   strcat(base,"/");
			   strcat(base,ptr->d_nSame);
			   readFileList(base);
			   */
		}
	}
	closedir(dir);

	//排序，按从小到大排序
	sort(files.begin(), files.end());
	return files;
}
//把信息写入字符串
void WriteToString(XMLElement* itemElement , const char * element_name , string& str)
{
	XMLElement* element = itemElement->FirstChildElement( element_name );
	if(element != nullptr)
	{
		//cout << "find " << element_name << endl;
		const char* text = element->GetText();
		str = text;
		boost::regex reg("<(\\S*?)[^>]*>.*?|<.*? />");
		str = boost::regex_replace(str, reg , "");
//		cout << "replace success!" << endl;
	}
	else str = "";
}
//把解析的内容写入RssItem中
void WriteToRssItem(XMLElement* itemElement , RssItem& ri)
{
	WriteToString(itemElement , "title" , ri.title);    //打印标题
	WriteToString(itemElement , "link" , ri.link);    //打印链接
	WriteToString(itemElement , "description" , ri.description);    //打印描述
	WriteToString(itemElement , "content:encoded", ri.content);    //打印内容
}
//功能：解析xml文件，生成我们的vector
void RssReader::parseRss(const string & filename)
{
	XMLDocument doc;
	const char* c_filename = filename.c_str();
	doc.LoadFile( c_filename );			//加载并解析文件
	if(doc.FirstChildElement( "rss" ) == nullptr) return; //如果不是rss文件，直接退出
	cout << "load " << c_filename << " success!" << endl;
	//XMLElement类的指针，我们获取到item元素，括号里面参数我们自己改一下就行
	XMLElement* itemElement = doc.FirstChildElement( "rss" )->FirstChildElement( "channel" )->FirstChildElement("item");
	while(itemElement != nullptr)
	{
		RssItem ri;
		WriteToRssItem(itemElement,ri);
		_rss.push_back(ri);
		itemElement = itemElement->NextSiblingElement();  //下一个兄弟结点
	}
}
RssReader::RssReader()                  //构造函数，啥也不做
{
	
}
//把vector中的元素输出到文件中去
void RssReader::dump(const string & filename)                  
{
	ofstream ofs(filename,std::ios::app);
	for (size_t idx=0; idx<_rss.size(); idx++)								//将一个个元素写入文件
	{
		ofs << "<docid> " << idx + 1 << " </docid>" << endl;
		_rss[idx].writeToFile(ofs);
	}
	_rss.erase(_rss.begin(),_rss.end());									//清空容器
	ofs.close();
	cout << "write " << filename << "success!" << endl;
}
int main(void)
{
	RssReader rss_reader;
	char current_address[100];
 	memset(current_address, '\0' , sizeof(current_address));
 	getcwd(current_address, 99); //获取当前路径
 	cout << "current_address = " << current_address << endl;
 	strcat(current_address, "/sources");
	vector<string> files = getFiles(current_address);			//获取文件名，组成一个vector
    string filename;
//	cout << "open file success!" << endl;
	for (size_t i=0; i<files.size(); i++)								//分别解析每一个文件
	{
		filename ="sources/"+files[i];
		rss_reader.parseRss(filename);									//解析一个
		string output_filename = filename.substr(8,filename.length()-12);//生成输出文件名
    	output_filename = "output/" + output_filename + ".txt";
		
		rss_reader.dump(output_filename);										//生成一个
	}
	cout<<"The end..."<<endl;
	return 0;
}
