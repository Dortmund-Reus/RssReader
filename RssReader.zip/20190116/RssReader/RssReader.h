#ifndef __RSSREADER_H__
#define __RSSREADER_H__
#include <vector>
#include <string>
#include <fstream>

using std::string;
using std::vector;
using std::ofstream;

struct RssItem
{
    string title;
    string link;
    string description;
    string content;
    void writeToFile(ofstream & ofs);
};
    
class RssReader
{
public:
    RssReader();
    
    void parseRss(const string & filename);//解析
    void dump(const string & filename);//输出
private:
    vector<RssItem> _rss;
    //char* _current_address;
};  

#endif
