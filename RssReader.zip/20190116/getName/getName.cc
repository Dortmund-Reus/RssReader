/**
 * @function: 获取cate_dir目录下的所有文件名
 * @param: cate_dir - string类型
 * @result：vector<string>类型
*/
#include "getName.h"
using std::string;
using std::cout;
using std::cin;
using std::endl;
using std::vector;
vector<string> getFiles(string cate_dir)
{
	vector<string> files;//存放文件名
 
 
	DIR *dir;
	struct dirent *ptr;
	char base[1000];
 
	if ((dir=opendir(cate_dir.c_str())) == NULL)
        {
		perror("Open dir error...");
                exit(1);
        }
 
	while ((ptr=readdir(dir)) != NULL)
	{
		if(strcmp(ptr->d_name,".")==0 || strcmp(ptr->d_name,"..")==0)    ///current dir OR parrent dir
		        continue;
		else if(ptr->d_type == 8)    ///file
			//printf("d_name:%s/%s\n",basePath,ptr->d_name);
			files.push_back(ptr->d_name);
		else if(ptr->d_type == 10)    ///link file
			//printf("d_name:%s/%s\n",basePath,ptr->d_name);
			continue;
		else if(ptr->d_type == 4)    ///dir
		{
			files.push_back(ptr->d_name);
			/*
		        memset(base,'\0',sizeof(base));
		        strcpy(base,basePath);
		        strcat(base,"/");
		        strcat(base,ptr->d_nSame);
		        readFileList(base);
			*/
		}
	}
	closedir(dir);
 
	//排序，按从小到大排序
	sort(files.begin(), files.end());
	return files;
}
int main(void)
{
	char current_address[100];
	memset(current_address, '\0' , sizeof(current_address));
	getcwd(current_address, 99); //获取当前路径
	cout << "current_address = " << current_address << endl;
	strcat(current_address, "/sources");
 
	cout << "current_address = " << current_address << endl;
	vector<string> files=getFiles(string(current_address));
	for (size_t i=0; i<files.size(); i++)
	{
		cout<<files[i]<<endl;
	}
 
	//cout<<"Hello World"<<endl;
 
	cout<<"end..."<<endl;
	return 0;
}
