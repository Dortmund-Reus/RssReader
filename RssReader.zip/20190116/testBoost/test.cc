#include <iostream>
#include <boost/regex.hpp>
#include <string>
using std::string;

int main(void)
{
    std::string str("abcd");
    boost::regex reg( "a\\w*d" );
    if (regex_match(str, reg))
    {
        std::cout << str << " is match" << std::endl;
    }
    else
    {
        std::cout << str << " is not match" << std::endl;
    }
    return 0;
}
