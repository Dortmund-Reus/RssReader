#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <string>
#include <set>
#include <exception>
#include <iostream>

using std::cout;
using std::endl;

struct RssItem
{
    std::string m_file;               // log filename
    int m_level;                      // debug level
    std::set<std::string> m_modules;  // modules where logging is enabled
    void load(const std::string &filename);
    void save(const std::string &filename);
};

void RssItem::load(const std::string &filename)
{
    using boost::property_tree::ptree;// 创建一个空的ptree对象
    ptree pt;
    read_xml(filename, pt);// 把XML文件加载到property_tree对象中去。如果读取失败，会抛出一个异常
    m_file = pt.get<std::string>("debug.filename"); // 这个get方法获得文件名并把它存储在m_file变量中。注意，我们通过用.分隔独立的
                                                    // keys来构成完整的路径。如果点出现在keys中，我们可以考虑换一个分隔符
                                                    // 如果debug.filename这个键值找不到，就会抛出一个异常

    m_level = pt.get("debug.level", 0);             // 获得debug级别并把它存储在m_level变量中。这个是get方法的另一个版本：
                                                    // 如果没有找到值，就返回第二个参数指定的默认值。提取的值的类型由第二参数
                                                    // 的类型确定,所以我们不妨用这种写法代替get<int>()的写法

    pt.erase("debug.level");
    BOOST_FOREACH(ptree::value_type &v,             // 迭代debug.modules部分并且把所有发现的modules都存储在m_modules这个set
        pt.get_child("debug.modules"))              // 中。get_child()方法返回一个指向特定路径上的子元素；如果没有子元素，它会抛出
            m_modules.insert(v.second.data());      // Property tree迭代器是BidirectionalIterator的实例。
            //把v的第二个数据传给set?
          
}

void RssItem::save(const std::string &filename)
{
    using boost::property_tree::ptree;
    ptree pt;
    pt.put("debug.filename", m_file);
    pt.put("debug.level", m_level);
    BOOST_FOREACH(const std::string &name, m_modules)
        pt.add("debug.modules.module", name);
    write_xml(filename, pt);
}
int main()
{
    try
    {
        RssItem ds;
        ds.load("RssItem.xml");
        ds.save("RssItem_out.xml");
        std::cout << "Success\n";
    }
    catch (std::exception &e)
    {
        std::cout << "Error: " << e.what() << "\n";
    }
    return 0;
}
