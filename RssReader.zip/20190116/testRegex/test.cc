#include <iostream>
#include <boost/regex.hpp>
#include <boost/algorithm/string.hpp>
void TestReplace()
{
    std::string context("<p></p><ios>hello world!</ios>");
    boost::regex reg("<(\\S*?)[^>]*>.*?|<.*? />");
	std::string str = boost::regex_replace(context, reg, "");
	std::cout << context << std::endl;
	std::cout << str << std:: endl;
}
int main(void)
{
	TestReplace();
	return 0;
}
